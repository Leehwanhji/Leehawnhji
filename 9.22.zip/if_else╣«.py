print "Tell me your age"
myage = int(raw_input())
if myage<30:
    print "Welcome to the Club"
else:
    print "Oh! No. Here is not a travel night club"
