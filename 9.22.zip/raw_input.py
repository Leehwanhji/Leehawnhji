print "Enter your name:"
somebody = raw_input()
print "Hi", somebody, "How are you today?"
