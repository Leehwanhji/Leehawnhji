for looper in[1,2,3,4,5]:
    print "hello"
for looper in "abcde":
    print "hello"
for looper in["k","0","R","e","a"]:
    print "h"
for looper in["sok","sag","jim"]:
    print "hel"
