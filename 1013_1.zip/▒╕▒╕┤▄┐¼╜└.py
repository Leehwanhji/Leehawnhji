# -*- coding: utf-8 -*-

print "구구단 몇단 계산?(1~9)"
x = 1
while(x<>0):
    x = int(raw_input())
    if x == 0: break
    if not(1 <= x <= 9):
        print "잘못입력했소","1부터9요"
        continue
    else:
        print "구구단" + str(x) +"단 계산함"
        for i in range(1,10):
            print str(x) + "X" + str(i) + "=" + str(x*i)
        print "구구단 몇단 계산할깝쇼?"
    print "구구단겜종료"
