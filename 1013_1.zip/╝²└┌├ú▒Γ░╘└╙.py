#_*_coding: utf_8_*_

import random
guess_number = random.randint(1,100)
print "숫자 맞춰(1~100)"
users_input = int(raw_input())
while(users_input <> guess_number):
    if users_input > guess_number:
        print "숫자가 큼"
    else:
        print "숫자가 작음"
    users_input = int(raw_input())
else:print "정답","입력한숫자는",users_input,"임"
